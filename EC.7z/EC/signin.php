<?php
require 'config.php';
 
if(isset($_POST["submit"])){
  $usernameemail = $_POST["usernameemail"];
  $password = $_POST["password"];
  $result = mysqli_query($conn, "SELECT * FROM tb_user WHERE username = '$usernameemail' OR email = '$usernameemail'");
  $row = mysqli_fetch_assoc($result);
  if(mysqli_num_rows($result) > 0){
    if($password == $row['password']){
      $_SESSION["login"] = true;
      $_SESSION["id"] = $row["id"];
      header("Location: home.php");
    }
    else{
      echo
      "<script> alert('Wrong Password'); </script>";
    }
  }
  else{
    echo
    "<script> alert('User Not Registered'); </script>";
  }
}
?>

<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="stylesignin&signup.css">
        <title>Sign Up</title>
    </head>
<body>
    <!-- NAV BAR -->
    <div class="Navbar">
       <a href="Home1.php"> <div class="logo"> <h1 style="color: white; letter-spacing: 4px;"><i>Queen's</i></h1> </div></a>
        <div class="searchbar">
            <a href="signup.php"> <i> Sign Up</i></a> 
            <a href="signin.php"><i> Sign In</i></a>        
        </div>
    </div>
    <!-- FORM -->
    <div class="container">
    <form class="" action="" method="post" autocomplete="off">
            <div class="outer">  
                 
                    <div class="logo"> <h1 style="color: white; letter-spacing: 4px;"><i>Queen's</i></h1> </div>
                    <div class="profile">
                        <img src="rename.png">
                    </div>
                <div class="inputbox">
                    <h3>Name: </h3>
                    <input placeholder="Email or Phone Number" type="text" name="usernameemail" id = "usernameemail" >
                </div>
                <div class="inputbox">
                    <h3>Name: </h3>
                    <input placeholder="Password" type="password"  name="password" id = "password" required value="">
                </div>
                 
                <br>
              
                    <button type="submit" name="submit">Sign In</button>
                    <br>
                    <br>
                    <p>Don't Have Account <a href="signup.html"><i> Sign Up</i></a>  </p> 
                   
                    <div class="media">
                        <a href="#"><img src="facebook.png"></a> 
                        <a href="#"><img src="insta.png"></a> 
                        <a href="#"><img src="twiter.png"></a> 
                        <a href="#"> <img src="whatsapp.png"></a> 
                    </div>
            

           </div>
        
        </form>



    </div>
</body>
 
</html>