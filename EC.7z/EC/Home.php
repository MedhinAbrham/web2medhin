
<?php
require 'config.php';
if(!empty($_SESSION["id"])){
  $id = $_SESSION["id"];
  $result = mysqli_query($conn, "SELECT * FROM tb_user WHERE id = $id");
  $row = mysqli_fetch_assoc($result);

  
}
else{
  header("Location: login.php");
}

if(isset($_POST["logout"])){
    require 'config.php';
    $_SESSION = [];
    session_unset();
    session_destroy();
    header("Location: signin.php");
    }

?>

<html>
    <head>
        <title>E-commerce</title>
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    </head>
    <body>
        <div class="Navbar">
            <div class="logo"> <h1 style="color: white; letter-spacing: 4px;"><i><b style="color: rgb(0, 116, 15);">Q</b>ueen's</i></h1> </div>
            <div class="search">
                <input type="search" placeholder="Search">
                <i class="fa-solid fa-search" style="background-color: rgb(255, 255, 255);"></i>
            </div>
            <div class="searchbar">        
                <a href="#Signup"> <i> Cart</i></a> 
                <a href="#Signup">  <i> Order</i></a> 
                <a href="#"> <i>  Hi: <?php echo $row["name"]; ?> </i></a> 

                <a href="logout.php" name><i> Logout</i></a>   
            </div>
        </div>

        <div class="menu">
            <ul class="drop">
                <li><a href="Home.html">Home</a></li>
                <li><a href="Furniture.html">Furniture</a>
                    <ul class="dropdown">
                        <li><a href="Furniture-home.html">Home</a></li>
                        <li><a href="Furniture_office.html">Office</a></li>
                    </ul>
                </li>
                <li><a href="Foods.html">Foods</a>
                    <ul class="dropdown">
                        <li><a href="Foods-Cultural.html">Cultural</a></li>
                        <li><a href="Foods-Modern.html">Modern</a></li>
                    </ul>
                </li>
                <li><a href="Beverages.html">beverages</a>
                    <ul class="dropdown">
                        <li><a href="Beverages-softDrink.html">Soft Drink</a></li>
                        <li><a href="Beverages-Alcohol.html">Alcohol</a></li>
                    </ul>
                </li>
                <li><a href="Clothing.html">clothing</a>
                    <ul class="dropdown">
                        <li><a href="Clothing-Traditional.html">Traditional</a></li>
                        <li><a href="Clothin-Modern.html">Modern</a></li>
                    </ul>
                </li>
                <li><a href="Sanitation.html">Sanitation</a>
                </li>
                <li><a href="Electronics.html">Electronics</a>
                    <ul class="dropdown">
                        <li><a href="Electronics-Computer.html">Computer</a></li>
                        <li><a href="Electronics-Mobile.html">Mobile</a></li>
                    </ul>
                </li><li><a href="Beauty.html">beauty</a>
                    <ul class="dropdown">
                        <li><a href="Beauty-Male.html">Male</a></li>
                        <li><a href="Beauty-Female.html">Female</a></li>
                    </ul>
                </li>

                
            </ul>
        </div>

        <div class="AD">

            <div class="Aditem"><img src="ADDD.jpg"> </div>
           
           
        </div>

        <h1 style="margin-left: 30px;">Top Sales</h1>

        <div class="Product">

            <div class="Pitem">
                <div><img src="shoes1.jpg"> </div>
                <div class="di">
                <div class="description"> <h3>  Nike</h3>  <h3>Price: 150$</h3></div>
            <div class="iconn"><h2>&#10133;</h2> </div>
        </div>
            </div>
            <div class="Pitem">
                <div><img src="shoes1.png"> </div>
                <div class="di">
                <div class="description"> <h3>  Nike</h3>  <h3>Price: 150$</h3></div>
            <div class="iconn"><h2>&#10133;</h2> </div>
        </div>
            </div> <div class="Pitem">
                <div><img src="sh1.jpg"> </div>
                <div class="di">
                <div class="description"> <h3>  Nike</h3>  <h3>Price: 150$</h3></div>
            <div class="iconn"><h2>&#10133;</h2> </div>
        </div>
            </div> <div class="Pitem">
                <div><img src="trou1.jpg"> </div>
                <div class="di">
                <div class="description"> <h3>  Nike</h3>  <h3>Price: 150$</h3></div>
            <div class="iconn"><h2>&#10133;</h2> </div>
        </div>
            </div>
            <div class="Pitem">
                <div><img src="trou5.jpg"> </div>
                <div class="di">
                <div class="description"> <h3>  Nike</h3>  <h3>Price: 150$</h3></div>
            <div class="iconn"><h2>&#10133;</h2> </div>
        </div>
            </div> <div class="Pitem">
                <div><img src="shr3.jpg"> </div>
                <div class="di">
                <div class="description"> <h3>  Nike</h3>  <h3>Price: 150$</h3></div>
            <div class="iconn"><h2>&#10133;</h2> </div>
        </div>
    </div> <div class="Pitem">
        <div><img src="shr1.jpg"> </div>
        <div class="di">
        <div class="description"> <h3>  Nike</h3>  <h3>Price: 150$</h3></div>
    <div class="iconn"><h2>&#10133;</h2> </div>
</div>
            </div>
           
        </div>

        <h1 style="margin-left: 30px;">New Product</h1>

        <!-- product 2 -->

        <div class="Product2">

            <div class="Pitem">
                <div><img src="shoes1.jpg"> </div>
                <div class="di">
                <div class="description"> <h3>  Nike</h3>  <h3>Price: 150$</h3></div>
            <div class="iconn"><h2>&#10133;</h2> </div>
        </div>
            </div>
            <div class="Pitem">
                <div><img src="shoes1.jpg"> </div>
                <div class="di">
                <div class="description"> <h3>  Nike</h3>  <h3>Price: 150$</h3></div>
            <div class="iconn"><h2>&#10133;</h2> </div>
        </div>
            </div> <div class="Pitem">
                <div><img src="shoes1.jpg"> </div>
                <div class="di">
                <div class="description"> <h3>  Nike</h3>  <h3>Price: 150$</h3></div>
            <div class="iconn"><h2>&#10133;</h2> </div>
        </div>
            </div> <div class="Pitem">
                <div><img src="shoes1.jpg"> </div>
                <div class="di">
                <div class="description"> <h3>  Nike</h3>  <h3>Price: 150$</h3></div>
            <div class="iconn"><h2>&#10133;</h2> </div>
        </div>
            </div>
            <div class="Pitem">
                <div><img src="shoes1.jpg"> </div>
                <div class="di">
                <div class="description"> <h3>  Nike</h3>  <h3>Price: 150$</h3></div>
            <div class="iconn"><h2>&#10133;</h2> </div>
        </div>
            </div>  
        </div>

         
        <!-- product3 -->

        <div class="Product2">

            <div class="Pitem">
                <div><img src="shoes1.jpg"> </div>
                <div class="di">
                <div class="description"> <h3>  Nike</h3>  <h3>Price: 150$</h3></div>
            <div class="iconn"><h2>&#10133;</h2> </div>
        </div>
            </div>
            <div class="Pitem">
                <div><img src="shoes1.jpg"> </div>
                <div class="di">
                <div class="description"> <h3>  Nike</h3>  <h3>Price: 150$</h3></div>
            <div class="iconn"><h2>&#10133;</h2> </div>
        </div>
            </div> <div class="Pitem">
                <div><img src="shoes1.jpg"> </div>
                <div class="di">
                <div class="description"> <h3>  Nike</h3>  <h3>Price: 150$</h3></div>
            <div class="iconn"><h2>&#10133;</h2> </div>
        </div>
            </div> <div class="Pitem">
                <div><img src="shoes1.jpg"> </div>
                <div class="di">
                <div class="description"> <h3>  Nike</h3>  <h3>Price: 150$</h3></div>
            <div class="iconn"><h2>&#10133;</h2> </div>
        </div>
            </div>
            <div class="Pitem">
                <div><img src="shoes1.jpg"> </div>
                <div class="di">
                <div class="description"> <h3>  Nike</h3>  <h3>Price: 150$</h3></div>
            <div class="iconn"><h2>&#10133;</h2> </div>
        </div>
            </div> <div class="Pitem">
                <div><img src="shoes1.jpg"> </div>
                <div class="di">
                <div class="description"> <h3>  Nike</h3>  <h3>Price: 150$</h3></div>
            <div class="iconn"><h2>&#10133;</h2> </div>
        </div>
    </div> <div class="Pitem">
        <div><img src="shoes1.jpg"> </div>
        <div class="di">
        <div class="description"> <h3>  Nike</h3>  <h3>Price: 150$</h3></div>
    <div class="iconn"><h2>&#10133;</h2> </div>
</div>
            </div>
           
        </div>

        <!-- product 4 -->
     
           
        <div class="Product2">

            <div class="Pitem">
                <div><img src="shoes1.jpg"> </div>
                <div class="di">
                <div class="description"> <h3>  Nike</h3>  <h3>Price: 150$</h3></div>
            <div class="iconn"><h2>&#10133;</h2> </div>
        </div>
            </div>
            <div class="Pitem">
                <div><img src="shoes1.jpg"> </div>
                <div class="di">
                <div class="description"> <h3>  Nike</h3>  <h3>Price: 150$</h3></div>
            <div class="iconn"><h2>&#10133;</h2> </div>
        </div>
            </div> <div class="Pitem">
                <div><img src="shoes1.jpg"> </div>
                <div class="di">
                <div class="description"> <h3> Nike</h3>  <h3>Price: 150$</h3></div>
            <div class="iconn"><h2>&#10133;</h2> </div>
        </div>
            </div> <div class="Pitem">
                <div><img src="shoes1.jpg"> </div>
                <div class="di">
                <div class="description"> <h3> Nike</h3>  <h3>Price: 150$</h3></div>
            <div class="iconn"><h2>&#10133;</h2> </div>
        </div>
            </div>
            <div class="Pitem">
                <div><img src="shoes1.jpg"> </div>
                <div class="di">
                <div class="description"> <h3> Nike</h3>  <h3>Price: 150$</h3></div>
            <div class="iconn"><h2>&#10133;</h2> </div>
        </div>
            </div> <div class="Pitem">
                <div><img src="shoes1.jpg"> </div>
                <div class="di">
                <div class="description"> <h3> Nike</h3>  <h3>Price: 150$</h3></div>
            <div class="iconn"><h2>&#10133;</h2> </div>
        </div>
    </div> <div class="Pitem">
        <div><img src="shoes1.jpg"> </div>
        <div class="di">
        <div class="description"> <h3>  Nike</h3>  <h3>Price: 150$</h3></div>
    <div class="iconn"><h2>&#10133;</h2> </div>
</div>
            </div>
           
        </div>



        
        <footer class="foot">

             <div class="foot1">
                <h1 style="color: white; letter-spacing: 4px;"><i><b style="color: rgb(0, 116, 15);">Q</b>ueen's</i></h1>
             </div>
             <div class="foot2">
                <div class="media">
                    <a href="#"><img src="facebook.png"></a> 
                    <a href="#"><img src="insta.png"></a> 
                    <a href="#"><img src="twiter.png"></a> 
                    <a href="#"> <img src="whatsapp.png"></a> 
                </div>

            </div>
            <div class="foot3">
                <h1 style="color: white; letter-spacing: 4px;"><i><b style="color: rgb(0, 116, 15);">Q</b>ueen's</i></h1>

            </div>
        </footer>

      
<script>

    function dropdownMenu(){
    
        var X = document.getElementById("Dropdownclicl");
        if(X.className === "topnav"){
            X.className += " responsive";
        }
        else{
            X.className = "topnav";
        }
    
    }
    
    </script>
  
    </body>
</html>