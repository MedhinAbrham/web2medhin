<?php
require 'config.php';
 
if(isset($_POST["submit"])){
  $name = $_POST["name"];
  $username = $_POST["username"];
  $email = $_POST["email"];
  $password = $_POST["password"];
  $phone = $_POST["phone"];
  $confirmpassword = $_POST["confirmpassword"];
  $duplicate = mysqli_query($conn, "SELECT * FROM tb_user WHERE username = '$username' OR email = '$email'");
  if(mysqli_num_rows($duplicate) > 0){
    echo
    "<script> alert('Username or Email Has Already Taken'); </script>";
  }
  else{
    if($password == $confirmpassword){
      $query = "INSERT INTO tb_user VALUES('','$name','$username','$email','$password','$phone')";
      mysqli_query($conn, $query);
      echo
      "<script> alert('Registration Successful'); </script>";
    }
    else{
      echo
      "<script> alert('Password Does Not Match'); </script>";
    }
  }
}
?>

<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="stylesignin&signup.css">
        <title>Sign Up</title>
    </head>
<body>
    <!-- NAV BAR -->
    <div class="Navbar">
        <a href="Home1.php"> <div class="logo"> <h1 style="color: white; letter-spacing: 4px;"><i>Queen's</i></h1> </div></a>
         <div class="searchbar">
            <a href="signup.php"> <i> Sign Up</i></a> 
            <a href="signin.php"><i> Sign In</i></a>        
        </div>
    </div>
    <!-- FORM -->
    <div class="container">
    <form class="" action="" method="post" autocomplete="off">
            <div class="outer">  
                 
                    <div class="logo"> <h1 style="color: white; letter-spacing: 4px;"><i>Queen's</i></h1> </div>

              
                <label style="font-size:22px; color:aliceblue">Wellcome</label> 
                <div class="inputbox">
                    <h3>Name: </h3>
                    <input placeholder="Frist Name" type="text"  name="name" id = "name" required>
                </div>
                <div class="inputbox">
                    <h3>Name: </h3>
                    <input placeholder="Last Name" type="text" name="username" id = "username"  required>
                </div>
                <div class="inputbox" style="background: none; padding-left: 0;">
                    <label style="color: white; margin-left: 10px;" >Pa</label>
                    <input style="height:30px; width:500px" placeholder="Password" type="text" name="password" id = "password">
                    <label style="color: white; margin-left: 10px;" >Pa</label>
                    <input style="height:30px; width:500px" placeholder="Confirm password" type="text" name="confirmpassword" id = "confirmpassword">
                </div>
                <div class="inputbox">
                    <h3>Name: </h3>
                    <input placeholder="Email@" type="email" required="" name="email" id = "email">
                </div>
                <div class="inputbox">
                    <h3>Name: </h3>
                    <input placeholder="Phone Number" type="number" required="" name="phone" id = "phone">
                </div>
                    <button type="submit" name="submit">Sign Up</button>

                    <p>Already Have Account <a href="#Signup"><i> Sign In</i></a>  </p> 
                
                    <div class="media">
                        <a href="#"><img src="facebook.png"></a> 
                        <a href="#"><img src="insta.png"></a> 
                        <a href="#"><img src="twiter.png"></a> 
                        <a href="#"> <img src="whatsapp.png"></a> 
                    </div>
            

           </div>
        
        </form>



    </div>
</body>
 
</html>